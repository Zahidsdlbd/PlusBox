
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FFunctionError%2FPlusbox-FlaskApi%2F&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)

# This is an example of PlusBox Flask. You can update it further!
# Created by FunctionError (updated on: 21-12-2024)
# Example URLs:
# http://localhost:5000/channel/{channel_id}/playlist.m3u8
# http://localhost:5000/channel/ZeeBanglaHD/playlist.m3u8
